import tkinter as tk
from PIL import Image, ImageTk
import random

# Lista das imagens
images = {
    "a" : "A",
    "b" : "B",
    "c" : "C",
    "d" : "D",
    "e" : "E",
    "f" : "F",
    "g" : "G",
    "h" : "H",
    "i" : "I",
    "j" : "J",
    "k" : "K",
    "l" : "L",
    "m" : "M",
    "n" : "N",
    "o" : "O",
    "p" : "P",
    "q" : "Q",
    "r" : "R",
    "s" : "S",
    "t" : "T",
    "u" : "U",
    "v" : "V",
    "w" : "W",
    "x" : "X",
    "y" : "Y",
    "z" : "Z"

}

# Função para mostrar as imagens
def display_image():
    global current_image
    random_image = random.choice(list(images.keys()))
    current_image = random_image
    img = Image.open(f"{random_image}.png")
    img = img.resize((200, 200))
    img = ImageTk.PhotoImage(img)
    
    panel.configure(image=img)
    panel.image = img
    answer_label.config(text="")

# Função para verificar as respostas do usuário fuxiqueiro
def check_guess():
    user_guess = entry.get().lower()
    try:
        if user_guess == images[current_image].lower():  # Compare lowercase strings
            answer_label.config(text="Acertou!")
            update_score(True)
        else:
            answer_label.config(text="Errou. Tente novamente!")
            update_score(False)
    except KeyError:
        answer_label.config(text="Imagem inválida | ERROR")





# Função para atualizar a pontuação
def update_score(is_correct):
    global score
    if is_correct:
        score += 1
    else:
        score -= 1
    score_label.config(text=f"Pontuacao: {score}")

# Função do tempo
def start_timer():
    global timer
    timer = 120
    timer_label.config(text=f"Tempo restante: {timer}")
    root.after(1000, update_timer)

def update_timer():
    global timer
    timer -= 1
    timer_label.config(text=f"Tempo restante: {timer}")
    if timer > 0:
        root.after(1000, update_timer)
    else:
        answer_label.config(text="Acabou o tempo")
        entry.config(state="disabled")

# Criar a tela
root = tk.Tk()
root.title("Aprendendo libras")

# Painel para as imagens
panel = tk.Label(root)
panel.pack()

# Chutes do usuários
entry = tk.Entry(root)
entry.pack()

# Botão de chutes
submit_button = tk.Button(root, text="Responder", command=check_guess)
submit_button.pack()

# Botão das respostas
answer_label = tk.Label(root)
answer_label.pack()

# Botão de nova imagem
new_image_button = tk.Button(root, text="Nova imagem", command=display_image)
new_image_button.pack()

# Contador de pontuação
score = 0

# Mostrar a pontuação
score_label = tk.Label(root, text=f"Pontuacao: {score}")
score_label.pack()

# Mostrar o tempo
timer_label = tk.Label(root, text="Tempo restante: 10")
timer_label.pack()

# Começar a contagem
start_timer()

# Mostrar a primeira imagem
display_image()

root.mainloop()
